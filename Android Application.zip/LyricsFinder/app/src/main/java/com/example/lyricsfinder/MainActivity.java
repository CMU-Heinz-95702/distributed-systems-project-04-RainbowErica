/**
 * Author: Yujia Wei
 * Email: yujiawei@andrew.cmu.edu
 *
 * LLM Disclaimer: ChatGPT is used to debug and write part of the comments in this program
 */
package com.example.lyricsfinder;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;
import javax.net.ssl.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    // Views
    EditText editTextArtist, editTextSong;
    Button buttonFetchLyrics;
    TextView textViewLyrics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Requirement 1a: Using TextView, EditText, Button, and ScrollView
        // Initialize Views
        editTextArtist = findViewById(R.id.editTextArtist);
        editTextSong = findViewById(R.id.editTextSong);
        buttonFetchLyrics = findViewById(R.id.buttonFetchLyrics);
        textViewLyrics = findViewById(R.id.textViewLyrics);

        // Set OnClickListener for the button
        buttonFetchLyrics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Requirement 1b: Requires input from the user
                String artist = editTextArtist.getText().toString().trim();
                String song = editTextSong.getText().toString().trim();

                if (artist.isEmpty() || song.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both artist and song title.", Toast.LENGTH_SHORT).show();
                } else {
                    // Requirement 1c: Makes an HTTP request to your web service
                    fetchLyrics(artist, song);
                }
            }
        });
    }

    private void fetchLyrics(String artist, String song) {
        // Web service URL
        String urlString = "https://redesigned-parakeet-69gqgrw9x59xcwq-8080.app.github.dev/lyrics?artist="
                + URLEncoder.encode(artist, StandardCharsets.UTF_8)
                + "&song="
                + URLEncoder.encode(song, StandardCharsets.UTF_8);

        // Start a new thread for network operation
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Bypass SSL certificate validation for testing purposes
                    TrustManager[] trustAllCerts = new TrustManager[] {
                            new X509TrustManager() {
                                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                    return new java.security.cert.X509Certificate[]{};
                                }
                                public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                                public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                            }
                    };

                    SSLContext sc = SSLContext.getInstance("SSL");
                    sc.init(null, trustAllCerts, new java.security.SecureRandom());
                    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

                    // Ignore hostname verification
                    HostnameVerifier allHostsValid = new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    };
                    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

                    // Create URL and HttpsURLConnection
                    URL url = new URL(urlString);
                    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);

                    // Requirement 1d: Receives and parses a JSON formatted reply
                    int responseCode = conn.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        // Read the response
                        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String inputLine;
                        StringBuilder responseContent = new StringBuilder();

                        while ((inputLine = in.readLine()) != null) {
                            responseContent.append(inputLine);
                        }
                        in.close();

                        // Parse JSON response
                        JSONObject jsonResponse = new JSONObject(responseContent.toString());
                        JSONArray lyricsLines = jsonResponse.getJSONArray("lyrics_lines");

                        // Build lyrics string from lines
                        StringBuilder lyricsBuilder = new StringBuilder();
                        for (int i = 0; i < lyricsLines.length(); i++) {
                            lyricsBuilder.append(lyricsLines.getString(i)).append("\n");
                        }
                        String lyrics = lyricsBuilder.toString();

                        // Requirement 1e: Displays new information to the user
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textViewLyrics.setText(lyrics);
                            }
                        });
                    } else {
                        // Handle non-OK response
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "Error fetching lyrics.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    // Handle exceptions
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Network error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }
}
